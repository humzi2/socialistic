export const TrendData = [
  {
    name: "tendance 1",
    shares: 20,
    likes: 50,
  },
  {
    name: "tendance 2",
    shares: 30,
    likes: 70,
  },
  {
    name: "tendance 3",
    shares: 40,
    likes: 90,
  },
];
