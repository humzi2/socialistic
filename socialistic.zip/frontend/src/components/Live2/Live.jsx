import React, { useEffect } from 'react'

function Live() {

    useEffect(() => {
        alert('live')
    },[])

    return (
        <div>

        </div>
    )
}

export default Live


